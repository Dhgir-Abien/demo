(** L5：24-bit BMP 讀寫（BITMAPINFOHEADER，bottom-up，row 4-byte padding）。stdlib only。 *)
val read  : string -> Types.image
val write : string -> Types.image -> unit

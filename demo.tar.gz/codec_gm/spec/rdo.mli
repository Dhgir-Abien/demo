(** L3：前瞻決策（scanner + cost_evaluator + priority_arbiter）。

    對每 column、每 q_order ∈ {0,1,2,3}、每 codebook ∈ 0..table_num-1 計算 cost，取每 (col, order) 最小 codebook；
    再組成 12 個候選 idx 的總 cost：
      cost[idx] = ΣY/Co/Cg cost - rlc_buff[idx]，rlc_buff = zero_cost*rlc_num - (10|11)*rlc_header_num
      zero_cost = rgbg ? 8 : 12；idx 10/11 = Y cost + macro_cost（依 target 分段常數）
      data_num[idx] = ceil((cost + 131) / 96)
    選擇：第一個 data_num[idx] <= target 的 idx（0 優先）；皆不符 → idx 12，data_num = 12|24|46。
    這些常數全部集中在 [constants]，便於實驗改動。 *)

type constants = {
  header_size    : int;    (** 131 *)
  zero_cost      : int -> int;   (** rgbg → 8|12 *)
  macro_cost     : int -> int;   (** target → 常數 *)
  escape_penalty : int array;    (** 每 idx 的 10|11 *)
  fallback_num   : int -> int;   (** target → 12|24|46 *)
}

val rtl_constants : constants

type trace = {
  cost_vec       : int array;   (** 12 候選 cost *)
  data_num_vec   : int array;
  best_book      : int array array;   (** .(col).(order) *)
  rlc_num        : int array;   (** per idx *)
  rlc_header_num : int array;
}

val decide : ?consts:constants -> Tables.t -> Params.t -> rgb:int array -> Slice.decision * trace

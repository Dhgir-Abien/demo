(** L6：品質指標（唯一使用 float 的模組，不在 golden path 上）。 *)

type t = {
  psnr        : float;            (** 全 RGB，MSE 以 255 峰值 *)
  psnr_ch     : float array;      (** R,G,B *)
  max_err     : int;
  max_err_pos : int * int * int;  (** x, y, ch *)
  vif         : float;            (** pixel-domain VIF（Sheikh & Bovik 2006 簡化版，4 尺度 Gaussian） *)
}

val compare : orig:Types.image -> recon:Types.image -> t
val error_heatmap : orig:Types.image -> recon:Types.image -> Types.image
(** 每 pixel 取 max_ch |diff|，線性映射至 0..255 灰階（可換 colormap），輸出 BMP 用。 *)
val to_json : t -> string

(** L4：Frame 迭代與 .data 序列化。每 line 依 slice_num 切成 1/2/4 個獨立 slice。 *)

type slice_record = {
  y          : int;
  slice_idx  : int;
  decision   : Slice.decision;
  blocks     : int array array;
  stats      : Slice.stats;
  trace      : Rdo.trace;
}

val encode : Tables.t -> Params.t -> Types.image -> slice_record array * Types.image
(** 回傳所有 slice 記錄與 encoder 端重建影像。 *)

val decode : Tables.t -> Params.t -> w:int -> h:int -> slice_record array -> Types.image

(** L5：.data 純文字格式（UVM scoreboard 可直接讀）。

      # codec_gm v1 w=720 h=1280 slice_num=4 target=15 table_num=1
      S y=0 s=0 n=7 idx=3 cb=0,0,0
      0123456789abcdef01234567      (24 hex = 96 bit，block 0 = 最先輸出的 block，hex 為 [95:0])
      ...
      S y=0 s=1 n=9 ...

    stats sidecar（.stats.json）：每 slice 的 decision、cost_vec、rlc 統計、symbol_hist、bits_per_ch。 *)

val write : string -> Params.t -> w:int -> h:int -> Frame.slice_record array -> unit
val read  : string -> Params.t * int * int * (int * int * Slice.decision * int array array) array
val write_stats : string -> Frame.slice_record array -> unit
